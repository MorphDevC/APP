const DB_unique_words={
    word:{
        category:'category',
        properties:'properties',
        Categories:'Categories'
    },
    collections:{
        group_categories:'group_categories',
        support_collections_info:'support_collections_info',
        group_categories_edge:'group_categories_edge',
        properties_options:'properties_options'
    }
}

module.exports.word=DB_unique_words;